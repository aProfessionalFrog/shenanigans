import java.util.Scanner;

public class Adventure {
    public static void main(String[] args) {
        //Create pre-made Java classes
        Scanner userInput = new Scanner(System.in);


        /****************** Declare Variables ******************/

        //playerLevel holds the current level of the player character. Cannot be less than 1.
        int playerLevel = 1;

        //playerName holds the name of the player character. Cannot be empty.
        String playerName = "Mallis";

        //playerHealth holds the number of hit points the player has remaining.
        //If this reaches 0, the player has died.
        double playerHealth = 10.0;


        /********************* Game Play *********************/

        //setup and greeting
        System.out.println("What is your character's name?");
        playerName = userInput.nextLine();
        System.out.println("Welcome, " + playerName + "!");
        System.out.println("Before you is a large cave mouth. Darkness lies within." +
                "Dare you enter the Cave of Wonders?");
    }
}
