import java.util.Scanner;
import java.util.Random;

public class Adventure {
    public static void main(String[] args) {
        //Create pre-made Java classes
        Scanner userInput = new Scanner(System.in);
        Random randomGenerator = new Random();


        /****************** Declare Variables ******************/

        //playerLevel holds the current level of the player character. Cannot be less than 1.
        int playerLevel = 1;

        //playerName holds the name of the player character. Cannot be empty.
        String playerName = "Mallis";

        //playerHealth holds the number of hit points the player has remaining.
        //If this reaches 0, the player has died.
        double playerHealth = 10.0;

        //playerChoice holds the selections that the player makes.
        //It will usually be 1, 2, or 3 and should never be used without getting input first.
        int playerChoice;

        //rockDamage holds the amount of damage that the player takes from the rock trap.
        //It is randomly generated and will be between 0 and 5.
        int rockDamage;

        //hasSword holds whether the player has picked up the sword or not.
        boolean hasSword = false;


        /********************* Game Play *********************/

        //setup and greeting
        System.out.println("What is your character's name?");
        playerName = userInput.nextLine();
        System.out.println("Welcome, " + playerName + "!");
        System.out.println("Before you is a large cave mouth. Darkness lies within." +
                "Dare you enter the Cave of Wonders?");

        //player decides whether they want to enter the cave or not
        System.out.println("1. Enter the Cave of Wonders");
        System.out.println("2. Run away to the safety of your warm bed");
        playerChoice = userInput.nextInt();

        if(playerChoice == 1) {
            //the player enters the cave
            System.out.println("You walk through the entrance of the cave with " +
                    "your head held high.");
            playerLevel++;
            System.out.println("Your bravery has rewarded you! Congratulations, you are " +
                    "now level " + playerLevel);
        } else {
            System.out.println(playerName + " runs home and goes to sleep.");
            System.exit(0);
        }

        //player encounters a trap
        System.out.println("You travel forward into the dark cave. You feel something" +
                " press against your leg...");
        System.out.println("It's a trap! Suddenly you're being bombarded by rocks from above.");

        rockDamage = randomGenerator.nextInt(5);
        playerHealth -= rockDamage;
        System.out.println("The rockslide hits you for " + rockDamage + "!");
        System.out.println("You have " + playerHealth + " health remaining.");
        System.out.println("You pick yourself up from the cave floor and brush a" +
                " cloud of dust from your clothes.");

        //player encounters a chest
        System.out.println("The cave narrows as you press on until you manage to " +
                "squeeze through an opening into a large natural cavern.");
        System.out.println("Before you is a treasure chest.");
        System.out.println("1. Open the chest.");
        System.out.println("2. Ignore the chest. It is obviously another trap.");

        playerChoice = userInput.nextInt();
        if (playerChoice == 1) {
            System.out.println("Uneasy after your brush with death, you slowly open " +
                    "the chest to reveal a magical sword!");
            hasSword = true;
        }
    }
}
